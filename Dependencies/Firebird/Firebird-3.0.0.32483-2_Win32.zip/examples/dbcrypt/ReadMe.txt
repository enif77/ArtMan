All files in this directory are trivial samples.
They do not perform any real data encryption and should not be used in production!
